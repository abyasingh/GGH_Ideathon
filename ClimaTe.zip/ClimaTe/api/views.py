from django.shortcuts import render, HttpResponse
from rest_framework.response import Response
from rest_framework.decorators import api_view
# Create your views here.
def homepage(request):
    return render(request, "homep.html")

def air(request):
    return render(request, "air_box.html")

def water(request):
    return render(request, "water_pollution.html")

def deforestation(request):
    return render(request, "deforestation_rate.html")

def climate(request):
    return render(request, "climate_change.html")