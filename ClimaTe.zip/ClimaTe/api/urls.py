from django.urls import path
from api import views

urlpatterns = [
    path('', views.homepage, name='homepage'),
    path('air_box/', views.air, name='air_box'),
    path('water_pollution/', views.water, name='water_pollution'),
    path('deforestation_rate/', views.deforestation, name='deforestation_rate'),
    path('climate_change/', views.climate, name='climate_change'),
]